# Hướng dẫn quyền

**Từ bản 0.2.0 app cần 1 quyền bắt buộc (overlay) và 1 quyền tuỳ chọn (thông báo của chính app).**

Các quyền sẽ xuất hiện ở phase sau — chỉ xin khi tính năng cần, người dùng tự bật, không bypass bảo mật Android:

| Quyền | Dùng cho | Phase | Cách bật |
|---|---|---|---|
| Hiển thị trên ứng dụng khác (`SYSTEM_ALERT_WINDOW`) | Vẽ Island — **đã dùng ở bản này** | 4 | App tự mở trang cấp quyền; hoặc Cài đặt → Ứng dụng → Godly Island → Hiển thị trên các ứng dụng khác |
| Truy cập thông báo (`NotificationListenerService`) | Thông báo, nhạc (MediaSession), điều hướng Maps | 5–6 | Cài đặt → Thông báo → Truy cập thông báo |
| Thông báo của app (Android 13+, `POST_NOTIFICATIONS`) | Hiện dòng "Island đang chạy" — **đã dùng**; từ chối vẫn chạy | 4 | Hộp thoại hệ thống |
| Foreground service (`specialUse`) | Giữ Island sống — **đã dùng** | 4 | Tự động khi bật Island |
| Bỏ tối ưu pin | Island không bị hệ thống tắt | 4 | Tuỳ chọn, người dùng tự đồng ý |
| Bluetooth (`BLUETOOTH_CONNECT`) | Trạng thái tai nghe | 6 | Hộp thoại hệ thống |
| Điện thoại / Danh bạ | Tên người gọi, trả lời/từ chối | 6 | Chỉ xin nếu cần; Android có thể không cho |

Không có quyền nào đòi hỏi vô lý; không có server; không có API trả phí.
