# Hướng dẫn test

Sau khi cài APK (`INSTALL.md`):

## A. Island thật
1. Mở app → **Bật Dynamic Island**. Lần đầu app mở trang cấp quyền "Hiển thị trên các ứng dụng khác": bật cho Godly Island, quay lại, bấm bật lần nữa.
2. Island nhỏ phải hiện quanh camera ở đỉnh màn hình (nếu "Luôn hiện đảo nhỏ" bật). Nó hiện ra kiểu bật nảy nhẹ.
3. Mở **Cài đặt Island** → chọn **Mini / Expanded / Full / Dual** ở "Xem trước trên Island thật" → kéo thanh **Chiều ngang / Chiều cao** và xem Island thật đổi ngay.
4. Nếu Island lệch camera: chỉnh **Vị trí Ngang/Dọc** cho trùng lỗ camera. Ghi lại số bạn chọn gửi mình.
5. Chọn **Kiểu**: *Godly Color* (nhiều màu, sáng) và *iPhone 14 Pro Max (đen)*. Bấm "Dùng cỡ + kiểu iPhone 14 Pro Max".
6. Cắm/rút sạc: phải hiện "Đang sạc" (sự kiện thật). Pin ≤ 20% hiện cảnh báo.
7. Chạm vào Island đang có sự kiện = mở/thu; nhấn giữ = Full; vuốt lên = đóng.

## B. Test Mode
1. Trang chủ → **Mở Test Mode** → **Run All Tests** (~25 giây, đừng chạm màn hình).
2. Mục **Kết quả kiểm tra**: Shader thân Island, Shader lab (3 mức), Canvas, Auto-fallback = PASS. Chuyển cảnh/Animation/Performance = PASS hoặc SKIP kèm lý do.
3. Mục **Hiệu năng**: xem "Chuyển cảnh gần nhất" (TB, p95, tệ nhất, số frame rớt) và GPU time.
4. Nhìn bằng mắt:
   - Màu sáng, không tối/xám; mỗi chức năng một màu; icon tự vẽ rõ nét.
   - **Icon không bị lún** vào mép ở Mini, Dual, Full; chữ không bị cắt khi chuyển.
   - Mép kính "hút vào" mềm, **không có gợn sóng, không có vệt bóng láng quét**.
   - Mini → Expanded → Full → Dual mượt, không giật.
5. **Apply Settings** (mở sau khi Test Liquid Glass đạt) đẩy kiểu/màu sang Island thật.

## Gửi lại cho mình
- Ảnh chụp Island thật (Mini + Expanded) và mục Hiệu năng + Kết quả + Error log.
- Island có lag không? Lag lúc nào (mở ra / thu lại / chuyển Dual / lúc đứng yên)?
- Vị trí Ngang/Dọc bạn chỉnh để trùng camera.

## Tiêu chí đạt
- Không crash, không "FAIL".
- Chuyển cảnh: số frame rớt ≤ ~10%.
- Mắt thấy đúng mục B4.
