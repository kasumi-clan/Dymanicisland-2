package com.godly.island.testing

import android.os.Build
import android.os.SystemClock
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godly.island.core.ErrorLog
import com.godly.island.core.GodlyButton
import com.godly.island.core.GodlyChip
import com.godly.island.core.GodlyColors
import com.godly.island.core.PerfMonitor
import com.godly.island.core.PerfSnapshot
import com.godly.island.core.SectionTitle
import com.godly.island.events.IslandEvent
import com.godly.island.events.IslandKind
import com.godly.island.island.IslandAnimationController
import com.godly.island.island.IslandEventManager
import com.godly.island.island.IslandRuntime
import com.godly.island.island.IslandSettings
import com.godly.island.island.IslandShape
import com.godly.island.island.IslandStyle
import com.godly.island.island.IslandView
import com.godly.island.renderer.GlassConfig
import com.godly.island.renderer.GlassEngine
import com.godly.island.renderer.GlassQuality
import com.godly.island.renderer.IslandMaterial
import com.godly.island.renderer.LiquidGlassRenderer
import com.godly.island.renderer.RenderMode
import com.godly.island.settings.GlassSettingsStore
import java.util.Locale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class TestStatus { PASS, FAIL, SKIP }

data class TestResult(val name: String, val status: TestStatus, val detail: String)

private fun f1(v: Float): String = String.format(Locale.US, "%.1f", v)
private fun f2(v: Float): String = String.format(Locale.US, "%.2f", v)

private fun perfResult(name: String, s: PerfSnapshot): TestResult {
    if (s.frames < 5) {
        return TestResult(name, TestStatus.SKIP, "Hệ thống chỉ báo " + s.frames + " frame — không đủ dữ liệu để đo")
    }
    val gpu = if (s.gpuMs >= 0f) " • GPU " + f1(s.gpuMs) + " ms" else ""
    val detail = f1(s.fps) + " fps • " + f1(s.frameMs) + " ms/frame" + gpu +
        " • jank " + f1(s.jankPercent) + "% (ngân sách " + f1(s.budgetMs) + " ms)"
    return TestResult(name, if (s.jankPercent <= 20f) TestStatus.PASS else TestStatus.FAIL, detail)
}

/**
 * Test Mode: the Island preview (the SAME IslandView as the real overlay) on top, controls / tests /
 * live stats below. Events are simulated only; nothing real is posted or sent.
 * "Apply Settings" saves the Liquid Glass lab config and pushes the Island look to the REAL Island.
 */
@Composable
fun IslandTestPanel(store: GlassSettingsStore, perf: PerfMonitor, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var appliedGlass by remember { mutableStateOf(store.load()) }
    var draftGlass by remember { mutableStateOf(appliedGlass) }
    var draftIsland by remember { mutableStateOf(IslandRuntime.settings) }
    var shape by remember { mutableStateOf(IslandShape.EXPANDED) }
    var events by remember {
        mutableStateOf<List<IslandEvent>>(listOf(IslandEventSimulator.sample(IslandKind.MUSIC)))
    }
    var busy by remember { mutableStateOf<String?>(null) }
    var glassTestedKey by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val results = remember { mutableStateListOf<TestResult>() }
    val shaderStatus = remember { mutableStateMapOf<String, String>() }

    val labEngine = remember(draftGlass.quality) { GlassEngine.create(context, draftGlass.quality) }
    val labPath = LiquidGlassRenderer.resolve(draftGlass, labEngine)
    val islandMaterial = remember { IslandMaterial.create(context) }
    val live = perf.live

    // ---------- event / shape helpers ----------
    fun selectShape(s: IslandShape) {
        if (s.dual) {
            if (events.size < 2) events = IslandEventSimulator.dualSample()
        } else if (events.isEmpty() && s != IslandShape.HIDDEN) {
            events = listOf(IslandEventSimulator.sample(IslandKind.MUSIC))
        }
        shape = s
    }

    fun playEvent(kind: IslandKind) {
        val first = IslandEventSimulator.sample(kind)
        events = listOf(first)
        shape = IslandEventSimulator.recommendedShape(kind)
        if (kind in IslandEventSimulator.animatedKinds) {
            scope.launch {
                var ev = first
                for (i in 1..20) {
                    delay(150)
                    if (events.firstOrNull()?.id != ev.id) break
                    val p = i / 20f
                    ev = ev.copy(progress = p, value = (p * 100f).toInt().toString() + "%")
                    events = listOf(ev)
                }
            }
        }
    }

    fun expandStep() {
        selectShape(
            when (shape) {
                IslandShape.HIDDEN -> IslandShape.MINI
                IslandShape.MINI -> IslandShape.EXPANDED
                IslandShape.EXPANDED -> IslandShape.FULL
                IslandShape.FULL -> IslandShape.MINI
                IslandShape.DUAL -> IslandShape.EXPANDED
            },
        )
    }

    // ---------- tests ----------
    suspend fun testGlass() {
        var ok = true
        for (q in GlassQuality.values()) {
            val e = GlassEngine.create(context, q)
            if (e.ready) {
                shaderStatus["Lab " + q.label] = "OK • " + e.compileMillis + " ms"
                results.add(TestResult("Shader lab " + q.label, TestStatus.PASS, "AGSL biên dịch OK (" + e.compileMillis + " ms)"))
            } else if (!LiquidGlassRenderer.shaderSupported) {
                shaderStatus["Lab " + q.label] = "Không hỗ trợ (cần Android 13+)"
                results.add(TestResult("Shader lab " + q.label, TestStatus.SKIP, "Android API " + Build.VERSION.SDK_INT + " < 33 → dùng Canvas"))
            } else {
                ok = false
                shaderStatus["Lab " + q.label] = "LỖI: " + (e.error ?: "không rõ")
                results.add(TestResult("Shader lab " + q.label, TestStatus.FAIL, e.error ?: "không rõ"))
            }
            delay(40)
        }
        val m = IslandMaterial.create(context)
        if (m.ready) {
            shaderStatus["Island"] = "OK • " + m.compileMillis + " ms"
            results.add(TestResult("Shader thân Island", TestStatus.PASS, "AGSL biên dịch OK (" + m.compileMillis + " ms)"))
        } else if (!LiquidGlassRenderer.shaderSupported) {
            shaderStatus["Island"] = "Không hỗ trợ (cần Android 13+)"
            results.add(TestResult("Shader thân Island", TestStatus.SKIP, "Android API " + Build.VERSION.SDK_INT + " < 33 → Canvas gradient"))
        } else {
            ok = false
            shaderStatus["Island"] = "LỖI: " + (m.error ?: "không rõ")
            results.add(TestResult("Shader thân Island", TestStatus.FAIL, m.error ?: "không rõ"))
        }
        val canvasOk = LiquidGlassRenderer.resolve(GlassConfig(mode = RenderMode.CANVAS), null) == LiquidGlassRenderer.Path.CANVAS
        results.add(TestResult("Canvas fallback", if (canvasOk) TestStatus.PASS else TestStatus.FAIL, "Chọn Canvas thủ công"))
        val autoOk = LiquidGlassRenderer.resolve(GlassConfig(mode = RenderMode.AUTO), null) == LiquidGlassRenderer.Path.CANVAS
        results.add(TestResult("Auto-fallback", if (autoOk) TestStatus.PASS else TestStatus.FAIL, "AUTO + shader không có → Canvas"))
        if (!canvasOk || !autoOk) ok = false
        results.add(
            TestResult("Kiểm tra bằng mắt", TestStatus.SKIP, "Nhìn Island: màu sáng, mép kính hút vào, icon cân giữa không bị lún"),
        )
        glassTestedKey = if (ok) draftGlass.quality.name + "/" + draftGlass.mode.name else null
    }

    suspend fun testAnimation() {
        val oldShape = shape
        val oldEvents = events
        perf.resetSession()
        val seq: List<Pair<IslandShape, IslandKind?>> = listOf(
            IslandShape.MINI to IslandKind.MUSIC,
            IslandShape.EXPANDED to IslandKind.CALL_INCOMING,
            IslandShape.FULL to IslandKind.NAVIGATION,
            IslandShape.DUAL to null,
            IslandShape.EXPANDED to IslandKind.NOTIFICATION,
            IslandShape.MINI to IslandKind.TIMER,
        )
        for ((s, k) in seq) {
            events = if (k == null) IslandEventSimulator.dualSample() else listOf(IslandEventSimulator.sample(k))
            shape = s
            delay(1100)
        }
        val snap = perf.sessionSnapshot()
        val st = IslandAnimationController.lastStats
        shape = oldShape
        events = oldEvents
        if (st != null) {
            val ok = st.dropped <= (st.frames / 10) + 1
            results.add(
                TestResult(
                    "Chuyển cảnh Island (lần cuối)",
                    if (ok) TestStatus.PASS else TestStatus.FAIL,
                    st.frames.toString() + " frame • TB " + f1(st.avgMs) + " ms • p95 " + f1(st.p95Ms) + " ms • tệ nhất " + f1(st.worstMs) + " ms • rớt " + st.dropped,
                ),
            )
        }
        results.add(perfResult("Animation Mini→Expanded→Full→Dual", snap))
    }

    suspend fun testEvents() {
        val oldShape = shape
        val oldEvents = events
        var emitted = 0
        val kinds = IslandKind.values()
        for (k in kinds) {
            var ev = IslandEventSimulator.sample(k)
            events = listOf(ev)
            shape = IslandEventSimulator.recommendedShape(k)
            if (k in IslandEventSimulator.animatedKinds) {
                for (i in 0..5) {
                    val p = i / 5f
                    ev = ev.copy(progress = p, value = (p * 100f).toInt().toString() + "%")
                    events = listOf(ev)
                    delay(110)
                }
            } else {
                delay(650)
            }
            if (ev.simulated) emitted++
        }
        events = IslandEventSimulator.dualSample()
        shape = IslandShape.DUAL
        delay(900)
        shape = oldShape
        events = oldEvents
        results.add(
            TestResult(
                "Event simulator",
                if (emitted == kinds.size) TestStatus.PASS else TestStatus.FAIL,
                emitted.toString() + "/" + kinds.size + " sự kiện giả lập + Dual đã phát. Không có thông báo/cuộc gọi thật. Nhìn preview để kiểm tra hiển thị.",
            ),
        )
    }

    suspend fun testPerformance() {
        val oldShape = shape
        val oldEvents = events
        perf.resetSession()
        val all = IslandKind.values()
        val t0 = SystemClock.elapsedRealtime()
        var i = 0
        while (SystemClock.elapsedRealtime() - t0 < 5000L) {
            val s = IslandShape.values()[1 + i % 4]
            events = if (s.dual) IslandEventSimulator.dualSample() else listOf(IslandEventSimulator.sample(all[i % all.size]))
            shape = s
            i++
            delay(700)
        }
        val snap = perf.sessionSnapshot()
        shape = oldShape
        events = oldEvents
        results.add(perfResult("Performance 5 s (" + draftIsland.style.label + ")", snap))
    }

    fun launchTest(name: String, clear: Boolean, block: suspend () -> Unit) {
        if (busy != null) return
        scope.launch {
            busy = name
            if (clear) results.clear()
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                ErrorLog.add("test", name + ": " + (t.message ?: t.javaClass.simpleName))
                results.add(TestResult(name, TestStatus.FAIL, t.message ?: t.javaClass.simpleName))
            } finally {
                busy = null
            }
        }
    }

    val currentKey = draftGlass.quality.name + "/" + draftGlass.mode.name
    val canApply = busy == null && glassTestedKey == currentKey
    val rendererLabel = when {
        draftIsland.style == IslandStyle.IPHONE_BLACK -> "Canvas (đen thuần)"
        draftIsland.useShader && islandMaterial.ready -> "AGSL procedural (GPU)"
        else -> "Canvas gradient (fallback)"
    }

    // ---------- UI ----------
    Column(modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
            Text("Test Mode", color = GodlyColors.Paper, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "Sự kiện ở đây đều giả lập. Chạm = mở rộng/thu nhỏ trong thực tế; vuốt lên = đóng; nhấn giữ = Full.",
                color = GodlyColors.Muted,
                fontSize = 11.sp,
            )
        }
        Box(
            Modifier
                .padding(horizontal = 12.dp)
                .fillMaxWidth()
                .height(250.dp)
                .clip(RoundedCornerShape(22.dp)),
        ) {
            TestBackdrop()
            IslandView(
                settings = draftIsland,
                shape = shape,
                events = events,
                topPaddingDp = 12f,
                onTap = { selectShape(if (shape == IslandShape.MINI) IslandShape.EXPANDED else IslandShape.MINI) },
                onLongPress = { selectShape(IslandShape.FULL) },
                onSwipeUp = { selectShape(IslandShape.HIDDEN) },
            )
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            PanelCard {
                SectionTitle("Hình dạng Island")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (s in IslandShape.values()) {
                        GodlyChip(s.label, shape == s, { selectShape(s) })
                    }
                }
                SectionTitle("Sự kiện giả lập")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (k in IslandKind.values()) {
                        GodlyChip(k.label, events.size == 1 && events[0].kind == k, { playEvent(k) })
                    }
                    GodlyChip("Dual event", shape.dual(), { selectShape(IslandShape.DUAL) })
                    GodlyChip(
                        "Xoá sự kiện",
                        events.isEmpty(),
                        {
                            events = emptyList()
                            shape = IslandShape.MINI
                        },
                    )
                }
            }

            PanelCard {
                SectionTitle("Kiểu & màu Island")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (st in IslandStyle.values()) {
                        GodlyChip(st.label, draftIsland.style == st, { draftIsland = draftIsland.copy(style = st) })
                    }
                }
                GodlyButton(
                    "Dùng cỡ + kiểu iPhone 14 Pro Max (đen)",
                    { draftIsland = draftIsland.withIphonePreset() },
                    Modifier.fillMaxWidth(),
                )
                ControlSlider("Độ sáng màu", draftIsland.brightness, 0f, 1f) { draftIsland = draftIsland.copy(brightness = it) }
                ControlSlider("Độ \"hút vào\" ở mép kính", draftIsland.lens, 0f, 1f) { draftIsland = draftIsland.copy(lens = it) }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Kính shader GPU", color = GodlyColors.Paper, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Switch(
                        checked = draftIsland.useShader,
                        onCheckedChange = { draftIsland = draftIsland.copy(useShader = it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = GodlyColors.Ink, checkedTrackColor = GodlyColors.Paper),
                    )
                }
                Text(
                    "Kích thước ngang/dọc chỉnh ở màn \"Cài đặt Island\" (mở từ trang chủ).",
                    color = GodlyColors.Muted,
                    fontSize = 11.sp,
                )
            }

            PanelCard {
                SectionTitle("Island thật")
                Text(
                    if (IslandRuntime.running) "Island thật: đang chạy" else "Island thật: đang tắt (bật ở trang chủ)",
                    color = if (IslandRuntime.running) GodlyColors.Ok else GodlyColors.Muted,
                    fontSize = 12.sp,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GodlyButton(
                        "Gửi sự kiện giả lên Island thật",
                        {
                            IslandEventManager.clearSimulated()
                            for (e in events.reversed()) IslandEventManager.post(e)
                        },
                        Modifier.weight(1f),
                        enabled = IslandRuntime.running && events.isNotEmpty(),
                    )
                    GodlyButton(
                        "Xoá sự kiện giả",
                        { IslandEventManager.clearSimulated() },
                        Modifier.weight(1f),
                        enabled = IslandRuntime.running,
                    )
                }
                Text(
                    "Chỉ đẩy sự kiện giả trong app vào Island thật. Không tạo thông báo hay cuộc gọi thật.",
                    color = GodlyColors.Muted,
                    fontSize = 11.sp,
                )
            }

            PanelCard {
                SectionTitle("Liquid Glass lab (kính lấy mẫu nền)")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LiquidGlassPreview(config = draftGlass.copy(mode = RenderMode.SHADER), label = "Shader", modifier = Modifier.weight(1f))
                    LiquidGlassPreview(config = draftGlass.copy(mode = RenderMode.CANVAS), label = "Canvas", modifier = Modifier.weight(1f))
                }
                ControlSlider("Blur (độ mờ)", draftGlass.blur, 0f, 1f) { draftGlass = draftGlass.copy(blur = it) }
                ControlSlider("Độ trong suốt", draftGlass.transparency, 0f, 1f) { draftGlass = draftGlass.copy(transparency = it) }
                ControlSlider("Phản chiếu", draftGlass.reflection, 0f, 2f) { draftGlass = draftGlass.copy(reflection = it) }
                ControlSlider("Độ sáng viền", draftGlass.border, 0f, 2f) { draftGlass = draftGlass.copy(border = it) }
                ControlSlider("Khúc xạ mép (hút vào)", draftGlass.lens, 0f, 1f) { draftGlass = draftGlass.copy(lens = it) }
                Text("Chất lượng", color = GodlyColors.Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (q in GlassQuality.values()) {
                        GodlyChip(q.label, draftGlass.quality == q, { draftGlass = draftGlass.copy(quality = q) })
                    }
                }
                Text("Renderer", color = GodlyColors.Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (m in RenderMode.values()) {
                        GodlyChip(m.label, draftGlass.mode == m, { draftGlass = draftGlass.copy(mode = m) })
                    }
                }
            }

            PanelCard {
                SectionTitle("Chạy kiểm tra")
                if (busy != null) {
                    Text("Đang chạy: " + busy, color = GodlyColors.Warn, fontSize = 12.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GodlyButton(
                        "Run All Tests",
                        {
                            launchTest("Run All Tests", true) {
                                testGlass()
                                testAnimation()
                                testEvents()
                                testPerformance()
                            }
                        },
                        Modifier.weight(1f),
                        enabled = busy == null,
                        filled = true,
                    )
                    GodlyButton("Test Liquid Glass", { launchTest("Test Liquid Glass", false) { testGlass() } }, Modifier.weight(1f), enabled = busy == null)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GodlyButton("Test Animation", { launchTest("Test Animation", false) { testAnimation() } }, Modifier.weight(1f), enabled = busy == null)
                    GodlyButton("Test Events", { launchTest("Test Events", false) { testEvents() } }, Modifier.weight(1f), enabled = busy == null)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GodlyButton("Test Performance", { launchTest("Test Performance", false) { testPerformance() } }, Modifier.weight(1f), enabled = busy == null)
                    GodlyButton(
                        "Reset Test",
                        {
                            draftGlass = appliedGlass
                            draftIsland = IslandRuntime.settings
                            shape = IslandShape.EXPANDED
                            events = listOf(IslandEventSimulator.sample(IslandKind.MUSIC))
                            results.clear()
                            shaderStatus.clear()
                            glassTestedKey = null
                            info = null
                            ErrorLog.clear()
                        },
                        Modifier.weight(1f),
                        enabled = busy == null,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GodlyButton(
                        "Apply Settings",
                        {
                            store.save(draftGlass)
                            appliedGlass = draftGlass
                            IslandRuntime.update(context) { cur -> draftIsland.copy(enabled = cur.enabled) }
                            info = "Đã lưu. Island thật dùng ngay kiểu/màu này (nếu đang bật)."
                            Toast.makeText(context, "Đã áp dụng", Toast.LENGTH_SHORT).show()
                            tick++
                        },
                        Modifier.weight(1f),
                        enabled = canApply,
                        filled = true,
                    )
                    GodlyButton(
                        "Restore Default",
                        {
                            appliedGlass = store.restoreDefault()
                            draftGlass = appliedGlass
                            IslandRuntime.update(context) { cur -> IslandSettings(enabled = cur.enabled) }
                            draftIsland = IslandRuntime.settings
                            glassTestedKey = null
                            info = "Đã khôi phục mặc định."
                        },
                        Modifier.weight(1f),
                        enabled = busy == null,
                    )
                }
                if (!canApply && busy == null) {
                    Text(
                        "Apply Settings mở khoá sau khi \"Test Liquid Glass\" (hoặc Run All) đạt với Chất lượng/Renderer đang chọn.",
                        color = GodlyColors.Muted,
                        fontSize = 11.sp,
                    )
                }
                val msg = info
                if (msg != null) Text(msg, color = GodlyColors.Ok, fontSize = 12.sp)
            }

            PanelCard {
                SectionTitle("Hiệu năng (đo thật từ hệ thống)")
                KeyValue("FPS", f1(live.fps) + (if (live.frames == 0) "  (đứng yên: không có frame)" else ""))
                KeyValue("Frame time", f1(live.frameMs) + " ms (ngân sách " + f1(live.budgetMs) + " ms)")
                KeyValue("Render time (draw)", f1(live.drawMs) + " ms")
                KeyValue("GPU time", if (live.gpuMs >= 0f) f1(live.gpuMs) + " ms" else "không có (cần Android 12+)")
                val st = IslandAnimationController.lastStats
                KeyValue(
                    "Chuyển cảnh gần nhất",
                    if (st == null) "chưa đo" else st.frames.toString() + " frame • TB " + f1(st.avgMs) + " • p95 " + f1(st.p95Ms) + " • tệ nhất " + f1(st.worstMs) + " ms • rớt " + st.dropped,
                )
                KeyValue("Bộ nhớ", "heap " + f1(live.heapMb) + " MB • native " + f1(live.nativeMb) + " MB")
                KeyValue("Current renderer (Island)", rendererLabel)
                KeyValue("GPU rendering mode (lab)", draftGlass.mode.label + " → " + labPath.name + " • " + draftGlass.quality.label)
                KeyValue("CPU cập nhật shader lab", f1(labEngine.cpuMicros) + " µs/frame")
                KeyValue("Animation state", shape.label + (if (busy != null) " • đang test" else ""))
                KeyValue(
                    "Current Island event",
                    if (events.isEmpty()) "(không có)" else events.joinToString(" + ") { it.kind.label },
                )
                KeyValue(
                    "Shader Island compile",
                    if (islandMaterial.ready) "OK • " + islandMaterial.compileMillis + " ms" else "Không dùng được: " + (islandMaterial.error ?: "đã lỗi lúc chạy"),
                )
                KeyValue(
                    "Shader lab compile",
                    if (labEngine.ready) "OK • " + labEngine.compileMillis + " ms" else "Không dùng được: " + (labEngine.error ?: "đã lỗi lúc chạy"),
                )
                for ((name, status) in shaderStatus) {
                    KeyValue("Shader " + name, status)
                }
            }

            PanelCard {
                SectionTitle("Kết quả kiểm tra")
                if (results.isEmpty()) {
                    Text("Chưa chạy bài kiểm tra nào.", color = GodlyColors.Muted, fontSize = 12.sp)
                }
                for (r in results) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        val c = when (r.status) {
                            TestStatus.PASS -> GodlyColors.Ok
                            TestStatus.FAIL -> GodlyColors.Bad
                            TestStatus.SKIP -> GodlyColors.Warn
                        }
                        Text(r.status.name, color = c, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 1.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.name, color = GodlyColors.Paper, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(r.detail, color = GodlyColors.Muted, fontSize = 11.sp)
                        }
                    }
                }
            }

            PanelCard {
                SectionTitle("Error log")
                val lines = ErrorLog.lines
                if (lines.isEmpty()) {
                    Text("Không có lỗi.", color = GodlyColors.Muted, fontSize = 12.sp)
                }
                for (line in lines.takeLast(10)) {
                    Text(line, color = GodlyColors.Bad, fontSize = 10.sp)
                }
            }
        }
    }
}

private fun IslandShape.dual(): Boolean = this == IslandShape.DUAL

@Composable
private fun PanelCard(content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .background(GodlyColors.Panel, shape)
            .border(1.dp, Color.White.copy(alpha = 0.10f), shape)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        content()
    }
}

@Composable
private fun ControlSlider(
    label: String,
    value: Float,
    min: Float,
    max: Float,
    onChange: (Float) -> Unit,
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = GodlyColors.Paper, fontSize = 12.sp)
            Text(f2(value), color = GodlyColors.Muted, fontSize = 12.sp)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = min..max,
            colors = SliderDefaults.colors(
                thumbColor = GodlyColors.Paper,
                activeTrackColor = GodlyColors.Paper,
                inactiveTrackColor = Color.White.copy(alpha = 0.2f),
            ),
        )
    }
}

@Composable
private fun KeyValue(key: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(key, color = GodlyColors.Muted, fontSize = 12.sp, modifier = Modifier.weight(0.42f))
        Text(
            value,
            color = GodlyColors.Paper,
            fontSize = 12.sp,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(0.58f),
        )
    }
}
