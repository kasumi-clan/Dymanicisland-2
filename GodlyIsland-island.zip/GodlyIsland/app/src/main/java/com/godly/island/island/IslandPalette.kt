package com.godly.island.island

import androidx.compose.ui.graphics.Color
import com.godly.island.events.IslandKind

/** Two accent colours per function. Bright mid-tones: readable with white text, never muddy. */
data class IslandAccent(val a: Color, val b: Color)

object IslandPalette {
    private val idle = IslandAccent(Color(0xFF444B63), Color(0xFF20263A))

    /** null = idle pill (no event). */
    fun accent(kind: IslandKind?): IslandAccent = when (kind) {
        null -> idle
        IslandKind.CALL_INCOMING -> IslandAccent(Color(0xFF24C777), Color(0xFF0B8F55))
        IslandKind.CALL_ONGOING -> IslandAccent(Color(0xFF19BDAA), Color(0xFF087F78))
        IslandKind.MUSIC -> IslandAccent(Color(0xFFFF4D8D), Color(0xFF7C3AED))
        IslandKind.BATTERY_LOW -> IslandAccent(Color(0xFFFF6A4D), Color(0xFFC71F4F))
        IslandKind.BATTERY_FULL -> IslandAccent(Color(0xFF34D27B), Color(0xFF0E9F6E))
        IslandKind.CHARGING -> IslandAccent(Color(0xFF2BD16C), Color(0xFF0E9F8E))
        IslandKind.NOTIFICATION -> IslandAccent(Color(0xFF3D8BFF), Color(0xFF5146E5))
        IslandKind.TIMER -> IslandAccent(Color(0xFFFF9A1F), Color(0xFFE8531D))
        IslandKind.NAVIGATION -> IslandAccent(Color(0xFF2E8BFF), Color(0xFF0FA89A))
        IslandKind.BLUETOOTH -> IslandAccent(Color(0xFF3B82F6), Color(0xFF1D4ED8))
        IslandKind.DOWNLOAD -> IslandAccent(Color(0xFF12B5E5), Color(0xFF2557F0))
        IslandKind.AI_PROCESSING -> IslandAccent(Color(0xFFA855F7), Color(0xFFE0409B))
    }
}
