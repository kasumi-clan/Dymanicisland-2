package com.godly.island.island

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateListOf
import com.godly.island.events.IslandEvent

/**
 * Holds the events the Island is showing (newest first, max 4). Main thread only.
 * Events with a ttl remove themselves. Updating an existing id (e.g. progress) does not re-trigger
 * the "attention" expand.
 */
object IslandEventManager {
    val events = mutableStateListOf<IslandEvent>()

    private val handler = Handler(Looper.getMainLooper())
    private val expiry = HashMap<String, Runnable>()

    fun post(e: IslandEvent) {
        val i = events.indexOfFirst { it.id == e.id }
        val isNew = i < 0
        if (isNew) events.add(0, e) else events[i] = e
        while (events.size > 4) events.removeAt(events.size - 1)
        expiry.remove(e.id)?.let { handler.removeCallbacks(it) }
        if (e.ttlMs > 0L) {
            val r = Runnable { remove(e.id) }
            expiry[e.id] = r
            handler.postDelayed(r, e.ttlMs)
        }
        IslandStateManager.onEventsChanged(isNew)
    }

    fun remove(id: String) {
        expiry.remove(id)?.let { handler.removeCallbacks(it) }
        val i = events.indexOfFirst { it.id == id }
        if (i >= 0) {
            events.removeAt(i)
            IslandStateManager.onEventsChanged(false)
        }
    }

    /** Swipe-up: dismiss the event on top. */
    fun dismissTop() {
        val top = events.firstOrNull() ?: return
        remove(top.id)
    }

    fun clearSimulated() {
        val ids = events.filter { it.simulated }.map { it.id }
        for (id in ids) remove(id)
    }

    fun clearAll() {
        for (r in expiry.values) handler.removeCallbacks(r)
        expiry.clear()
        events.clear()
        IslandStateManager.onEventsChanged(false)
    }
}
