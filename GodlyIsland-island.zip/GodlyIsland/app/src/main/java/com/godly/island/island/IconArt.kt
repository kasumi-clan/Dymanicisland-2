package com.godly.island.island

/** One drawing layer of an icon on a 24x24 grid. fill = filled path, otherwise a round-cap stroke. */
class IconLayer(
    val d: String,
    val fill: Boolean,
    val width: Float,
    val alpha: Float,
    val sc: Float = 1f,
    val tx: Float = 0f,
    val ty: Float = 0f,
)

/** Hand-drawn Godly icon set (SVG path data, 24x24). Generated from docs/icons preview; no emoji, no icon fonts. */
object IconArt {
    val CALL = listOf(
        IconLayer("M6.9 3.4 C6.0 3.2 5.1 3.5 4.5 4.2 C3.5 5.4 3.6 7.5 4.9 10.3 C6.4 13.6 9.0 16.5 12.4 18.5 C15.1 20.1 17.3 20.4 18.6 19.2 C19.4 18.5 19.7 17.6 19.5 16.8 L19.2 15.8 C19.0 15.1 18.5 14.7 17.9 14.5 L15.9 13.9 C15.3 13.7 14.7 13.9 14.3 14.3 L13.5 15.1 C13.2 15.4 12.8 15.4 12.4 15.2 C10.9 14.3 9.8 13.2 8.9 11.6 C8.7 11.2 8.7 10.8 9.0 10.5 L9.8 9.7 C10.2 9.3 10.4 8.7 10.2 8.1 L9.6 6.1 C9.4 5.5 9.0 5.0 8.4 4.8 Z", true, 0f, 1f),
    )
    val CALL_RING = listOf(
        IconLayer("M6.9 3.4 C6.0 3.2 5.1 3.5 4.5 4.2 C3.5 5.4 3.6 7.5 4.9 10.3 C6.4 13.6 9.0 16.5 12.4 18.5 C15.1 20.1 17.3 20.4 18.6 19.2 C19.4 18.5 19.7 17.6 19.5 16.8 L19.2 15.8 C19.0 15.1 18.5 14.7 17.9 14.5 L15.9 13.9 C15.3 13.7 14.7 13.9 14.3 14.3 L13.5 15.1 C13.2 15.4 12.8 15.4 12.4 15.2 C10.9 14.3 9.8 13.2 8.9 11.6 C8.7 11.2 8.7 10.8 9.0 10.5 L9.8 9.7 C10.2 9.3 10.4 8.7 10.2 8.1 L9.6 6.1 C9.4 5.5 9.0 5.0 8.4 4.8 Z", true, 0f, 1f, 0.82f, 1.2f, 3f),
        IconLayer("M14.2 4.6 A5.4 5.4 0 0 1 19.4 9.8", false, 1.9f, 1f),
        IconLayer("M14.2 1.4 A8.6 8.6 0 0 1 22.6 9.8", false, 1.9f, 0.65f),
    )
    val CALL_LIVE = listOf(
        IconLayer("M6.9 3.4 C6.0 3.2 5.1 3.5 4.5 4.2 C3.5 5.4 3.6 7.5 4.9 10.3 C6.4 13.6 9.0 16.5 12.4 18.5 C15.1 20.1 17.3 20.4 18.6 19.2 C19.4 18.5 19.7 17.6 19.5 16.8 L19.2 15.8 C19.0 15.1 18.5 14.7 17.9 14.5 L15.9 13.9 C15.3 13.7 14.7 13.9 14.3 14.3 L13.5 15.1 C13.2 15.4 12.8 15.4 12.4 15.2 C10.9 14.3 9.8 13.2 8.9 11.6 C8.7 11.2 8.7 10.8 9.0 10.5 L9.8 9.7 C10.2 9.3 10.4 8.7 10.2 8.1 L9.6 6.1 C9.4 5.5 9.0 5.0 8.4 4.8 Z", true, 0f, 1f, 0.82f, 0.8f, 3.2f),
        IconLayer("M15.4 3.6 V8.4", false, 2f, 1f),
        IconLayer("M19 2.4 V9.6", false, 2f, 0.85f),
        IconLayer("M22.2 4.4 V7.6", false, 2f, 0.7f),
    )
    val MUSIC = listOf(
        IconLayer("M9.2 17.2 V6.4 L19.2 4.4 V15.2", false, 1.9f, 1f),
        IconLayer("M9.2 6.0 L19.2 4.0 V7.6 L9.2 9.6 Z", true, 0f, 1f),
        IconLayer("M6.6 14.7 C8.0 14.7 9.2 15.7 9.2 17.0 C9.2 18.3 8.0 19.3 6.6 19.3 C5.2 19.3 4.0 18.3 4.0 17.0 C4.0 15.7 5.2 14.7 6.6 14.7 Z", true, 0f, 1f),
        IconLayer("M16.6 12.7 C18.0 12.7 19.2 13.7 19.2 15.0 C19.2 16.3 18.0 17.3 16.6 17.3 C15.2 17.3 14.0 16.3 14.0 15.0 C14.0 13.7 15.2 12.7 16.6 12.7 Z", true, 0f, 1f),
    )
    val BATTERY = listOf(
        IconLayer("M6.2 7.4 H16.6 A3 3 0 0 1 19.6 10.4 V13.6 A3 3 0 0 1 16.6 16.6 H6.2 A3 3 0 0 1 3.2 13.6 V10.4 A3 3 0 0 1 6.2 7.4 Z", false, 1.8f, 1f),
        IconLayer("M22 10.6 V13.4", false, 2f, 0.9f),
        IconLayer("M6.2 9.4 H16.6 A1.2 1.2 0 0 1 17.8 10.6 V13.4 A1.2 1.2 0 0 1 16.6 14.6 H6.2 A1.2 1.2 0 0 1 5.0 13.4 V10.6 A1.2 1.2 0 0 1 6.2 9.4 Z", true, 0f, 1f),
    )
    val BATTERY_LOW = listOf(
        IconLayer("M6.2 7.4 H16.6 A3 3 0 0 1 19.6 10.4 V13.6 A3 3 0 0 1 16.6 16.6 H6.2 A3 3 0 0 1 3.2 13.6 V10.4 A3 3 0 0 1 6.2 7.4 Z", false, 1.8f, 1f),
        IconLayer("M22 10.6 V13.4", false, 2f, 0.9f),
        IconLayer("M6.2 9.6 H8.4 A1.4 1.4 0 0 1 9.8 11 V13 A1.4 1.4 0 0 1 8.4 14.4 H6.2 A1.4 1.4 0 0 1 4.8 13 V11 A1.4 1.4 0 0 1 6.2 9.6 Z", true, 0f, 1f),
    )
    val CHARGING = listOf(
        IconLayer("M6.2 7.4 H16.6 A3 3 0 0 1 19.6 10.4 V13.6 A3 3 0 0 1 16.6 16.6 H6.2 A3 3 0 0 1 3.2 13.6 V10.4 A3 3 0 0 1 6.2 7.4 Z", false, 1.8f, 1f),
        IconLayer("M22 10.6 V13.4", false, 2f, 0.9f),
        IconLayer("M12.8 8.9 L9.9 12.6 H11.8 L11.3 15.3 L14.3 11.5 H12.4 Z", true, 0f, 1f),
    )
    val BELL = listOf(
        IconLayer("M12 3.4 C8.7 3.4 6.6 5.9 6.6 9.1 V11.6 C6.6 13.1 6.0 14.1 5.1 15.2 C4.6 15.8 5.0 16.8 5.8 16.8 H18.2 C19.0 16.8 19.4 15.8 18.9 15.2 C18.0 14.1 17.4 13.1 17.4 11.6 V9.1 C17.4 5.9 15.3 3.4 12 3.4 Z", true, 0f, 1f),
        IconLayer("M9.6 18.9 C9.9 20.1 10.8 20.8 12 20.8 C13.2 20.8 14.1 20.1 14.4 18.9 Z", true, 0f, 1f),
        IconLayer("M12 1.9 V3.6", false, 1.8f, 1f),
    )
    val TIMER = listOf(
        IconLayer("M12 21.2 A7.6 7.6 0 1 0 12 6 A7.6 7.6 0 0 0 12 21.2 Z", false, 1.9f, 1f),
        IconLayer("M9.4 2.8 H14.6", false, 1.9f, 1f),
        IconLayer("M12 6 V3.2", false, 1.9f, 1f),
        IconLayer("M12 13.6 L15.3 10.6", false, 2f, 1f),
        IconLayer("M12 12.1 A1.5 1.5 0 1 1 12 15.1 A1.5 1.5 0 0 1 12 12.1 Z", true, 0f, 1f),
        IconLayer("M18.6 6.2 L19.9 4.9", false, 1.8f, 0.85f),
    )
    val NAV = listOf(
        IconLayer("M20.4 3.6 L14.2 20.2 C13.9 21.0 12.8 20.9 12.6 20.1 L11.0 13.0 L3.9 11.4 C3.1 11.2 3.0 10.1 3.8 9.8 Z", true, 0f, 1f),
        IconLayer("M20.4 3.6 L14.2 20.2 L11.0 13.0 L3.8 9.8 Z", false, 1.2f, 1f),
    )
    val BLUETOOTH = listOf(
        IconLayer("M6.8 7.4 L16.8 16.2 L12 20.4 V3.6 L16.8 7.8 L6.8 16.6", false, 2f, 1f),
    )
    val DOWNLOAD = listOf(
        IconLayer("M12 3.6 V14.6", false, 2.1f, 1f),
        IconLayer("M7.4 10.4 L12 15 L16.6 10.4", false, 2.1f, 1f),
        IconLayer("M4.6 19.8 H19.4", false, 2.1f, 1f),
    )
    val SPARKLE = listOf(
        IconLayer("M10.6 3.0 C11.2 8.3 13.5 10.5 18.6 11.1 C13.5 11.7 11.2 13.9 10.6 19.2 C10.0 13.9 7.7 11.7 2.6 11.1 C7.7 10.5 10.0 8.3 10.6 3.0 Z", true, 0f, 1f),
        IconLayer("M18.8 2.4 C19.0 4.4 19.8 5.2 21.8 5.4 C19.8 5.6 19.0 6.4 18.8 8.4 C18.6 6.4 17.8 5.6 15.8 5.4 C17.8 5.2 18.6 4.4 18.8 2.4 Z", true, 0f, 1f),
        IconLayer("M17.8 15.6 C17.9 16.8 18.4 17.3 19.6 17.4 C18.4 17.5 17.9 18.0 17.8 19.2 C17.7 18.0 17.2 17.5 16.0 17.4 C17.2 17.3 17.7 16.8 17.8 15.6 Z", true, 0f, 0.85f),
    )
}
