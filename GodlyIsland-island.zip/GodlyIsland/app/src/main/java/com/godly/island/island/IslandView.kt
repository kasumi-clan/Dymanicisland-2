package com.godly.island.island

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godly.island.events.IslandEvent
import com.godly.island.events.IslandKind
import com.godly.island.renderer.IslandMaterial
import kotlin.math.roundToInt
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private data class ContentKey(val shape: IslandShape, val id: String?)

/** Smoothly blends the body colours when the event (and therefore the accent) changes. */
private class ColorTrack(initial: IslandAccent) {
    var fa = initial.a
    var fb = initial.b
    var ta = initial.a
    var tb = initial.b
    val t = Animatable(1f)

    fun a(): Color = lerp(fa, ta, t.value)
    fun b(): Color = lerp(fb, tb, t.value)

    suspend fun retarget(n: IslandAccent) {
        fa = a()
        fb = b()
        ta = n.a
        tb = n.b
        t.snapTo(0f)
        t.animateTo(1f, tween(IslandAnimationController.COLOR_MS, easing = IslandAnimationController.colorEasing))
    }
}

/**
 * The Dynamic Island. Used by the real overlay (GodlyIslandService) AND by Test Mode.
 *
 * Why it does not lag:
 *  - every animated value is an Animatable read ONLY in layout/draw lambdas -> no recomposition per frame;
 *  - the content is laid out once at its final size and revealed by the growing pill (clip + fade),
 *    so text is never re-measured while the Island morphs;
 *  - the body is one procedural shader draw (or plain Canvas for the black style): no offscreen layer,
 *    no texture reads, no ripple, no shine sweep;
 *  - nothing animates (and no frame is produced) while the Island is idle.
 */
@Composable
fun IslandView(
    settings: IslandSettings,
    shape: IslandShape,
    events: List<IslandEvent>,
    topPaddingDp: Float,
    modifier: Modifier = Modifier,
    onWindowNeeds: (Float, Float) -> Unit = { _, _ -> },
    onTransitionEnd: () -> Unit = {},
    onTap: () -> Unit = {},
    onLongPress: () -> Unit = {},
    onSwipeUp: () -> Unit = {},
) {
    val context = LocalContext.current
    val d = LocalDensity.current.density
    val haptic = LocalHapticFeedback.current
    val screenW = LocalConfiguration.current.screenWidthDp.toFloat()
    val scope = rememberCoroutineScope()

    val spec = settings.specFor(shape, screenW)
    val dualSpec = settings.specFor(IslandShape.DUAL, screenW)
    val window = settings.windowSizeDp(shape, screenW)
    val material = remember { IslandMaterial.create(context) }

    val tw = spec.w * d
    val th = spec.h * d
    val td = if (spec.dual) 1f else 0f

    // start small so the very first appearance is a pop-in, not a jump
    val wA = remember { Animatable(spec.h * d * 0.6f) }
    val hA = remember { Animatable(spec.h * d * 0.6f) }
    val dualA = remember { Animatable(0f) }
    val press = remember { Animatable(1f) }

    val primary = events.getOrNull(0)
    val secondary = events.getOrNull(1)
    val accentMain = IslandPalette.accent(primary?.kind)
    val accentSec = IslandPalette.accent(secondary?.kind)
    val trackMain = remember { ColorTrack(accentMain) }
    val trackSec = remember { ColorTrack(accentSec) }
    LaunchedEffect(accentMain) { trackMain.retarget(accentMain) }
    LaunchedEffect(accentSec) { trackSec.retarget(accentSec) }

    LaunchedEffect(tw, th, td) {
        onWindowNeeds(window.first, window.second) // grow the window first, shrink it after the morph
        val growing = tw * th >= wA.value * hA.value
        val fs = if (growing) IslandAnimationController.growSpec else IslandAnimationController.shrinkSpec
        IslandAnimationController.begin()
        coroutineScope {
            launch { wA.animateTo(tw, fs) }
            launch { hA.animateTo(th, fs) }
            launch { dualA.animateTo(td, IslandAnimationController.dualSpec) }
        }
        IslandAnimationController.end()
        onTransitionEnd()
    }

    val tapCb by rememberUpdatedState(onTap)
    val longCb by rememberUpdatedState(onLongPress)
    val swipeCb by rememberUpdatedState(onSwipeUp)
    val dragPx = 20f * d

    BoxWithConstraints(
        modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        scope.launch { press.animateTo(0.965f, tween(90)) }
                        tryAwaitRelease()
                        scope.launch { press.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 520f)) }
                    },
                    onTap = { tapCb() },
                    onLongPress = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        longCb()
                    },
                )
            }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -dragPx) swipeCb() },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            },
    ) {
        val cx = constraints.maxWidth / 2f
        val topPx = topPaddingDp * d
        val gapPx = DUAL_GAP_DP * d
        val maxR = 44f * d
        val rimCap = 26f * d
        val showSecond by remember { derivedStateOf { dualA.value > 0.02f } }
        val visible by remember { derivedStateOf { hA.value > 6f } }

        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = press.value
                    scaleY = press.value
                    transformOrigin = TransformOrigin(0.5f, 0f)
                },
        ) {
            Pill(
                x = { cx - wA.value / 2f + (-(gapPx / 2f) - wA.value / 2f) * dualA.value },
                y = { topPx },
                w = { wA.value },
                h = { hA.value },
                fade = { 1f },
                track = trackMain,
                material = material,
                settings = settings,
                maxRadiusPx = maxR,
                rimCapPx = rimCap,
                density = d,
                contentW = spec.w,
                contentH = spec.h,
            ) {
                if (visible) {
                    key(ContentKey(shape, primary?.id)) {
                        FadeIn(80L) { IslandContent(primary, shape, spec.h, settings.style) }
                    }
                }
            }
            if (showSecond) {
                Pill(
                    x = { cx + gapPx / 2f },
                    y = { topPx },
                    w = { wA.value * dualA.value },
                    h = { hA.value },
                    fade = { dualA.value.coerceIn(0f, 1f) },
                    track = trackSec,
                    material = material,
                    settings = settings,
                    maxRadiusPx = maxR,
                    rimCapPx = rimCap,
                    density = d,
                    contentW = dualSpec.w,
                    contentH = dualSpec.h,
                ) {
                    key(ContentKey(IslandShape.DUAL, secondary?.id)) {
                        FadeIn(140L) { IslandContent(secondary, IslandShape.DUAL, dualSpec.h, settings.style) }
                    }
                }
            }
        }
    }
}

@Composable
private fun Pill(
    x: () -> Float,
    y: () -> Float,
    w: () -> Float,
    h: () -> Float,
    fade: () -> Float,
    track: ColorTrack,
    material: IslandMaterial,
    settings: IslandSettings,
    maxRadiusPx: Float,
    rimCapPx: Float,
    density: Float,
    contentW: Float,
    contentH: Float,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = Modifier
            .offset { IntOffset(x().roundToInt(), y().roundToInt()) }
            .layout { measurable, _ ->
                val pw = w().roundToInt().coerceAtLeast(1)
                val ph = h().roundToInt().coerceAtLeast(1)
                val p = measurable.measure(Constraints.fixed(pw, ph))
                layout(pw, ph) { p.place(0, 0) }
            }
            .graphicsLayer {
                val r = minOf(h() / 2f, maxRadiusPx)
                shape = RoundedCornerShape(CornerSize(r))
                clip = true
                alpha = fade()
            }
            .drawBehind {
                val hh = size.height
                val r = minOf(hh / 2f, maxRadiusPx)
                drawIslandBody(
                    settings = settings,
                    material = material,
                    a = track.a(),
                    b = track.b(),
                    w = size.width,
                    h = hh,
                    r = r,
                    rimW = minOf(hh / 2f, rimCapPx),
                    dens = density,
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        // content has its FINAL size; the growing pill (clipped) reveals it
        Box(Modifier.requiredSize(contentW.dp, contentH.dp)) { content() }
    }
}

private fun DrawScope.drawIslandBody(
    settings: IslandSettings,
    material: IslandMaterial,
    a: Color,
    b: Color,
    w: Float,
    h: Float,
    r: Float,
    rimW: Float,
    dens: Float,
) {
    val sw = maxOf(1f, 1.1f * dens)
    if (settings.style == IslandStyle.IPHONE_BLACK) {
        drawRect(color = Color.Black, size = Size(w, h))
        drawRoundRect(
            color = Color.White.copy(alpha = 0.10f),
            topLeft = Offset(sw / 2f, sw / 2f),
            size = Size(w - sw, h - sw),
            cornerRadius = CornerRadius(maxOf(0f, r - sw / 2f)),
            style = Stroke(sw),
        )
        return
    }
    val ok = settings.useShader && material.draw(this, w, h, r, a, b, settings.brightness, settings.lens, rimW, 1f)
    if (ok) return
    // Canvas fallback (Android 12 and older, or shader unavailable): still coloured and bright
    drawRect(brush = Brush.linearGradient(listOf(a, b), start = Offset.Zero, end = Offset(w, h)), size = Size(w, h))
    drawRect(
        brush = Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.22f), Color.Transparent),
            startY = 0f,
            endY = h * 0.55f,
        ),
        size = Size(w, h),
    )
    drawRoundRect(
        brush = Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.65f),
                Color.White.copy(alpha = 0.12f),
                Color.White.copy(alpha = 0.40f),
            ),
            start = Offset.Zero,
            end = Offset(w, h),
        ),
        topLeft = Offset(sw / 2f, sw / 2f),
        size = Size(w - sw, h - sw),
        cornerRadius = CornerRadius(maxOf(0f, r - sw / 2f)),
        style = Stroke(sw),
    )
}

/** New content appears after a short delay with a soft scale + fade (GPU transform only). */
@Composable
private fun FadeIn(delayMs: Long, content: @Composable () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(delayMs)
        a.animateTo(1f, tween(220, easing = LinearOutSlowInEasing))
    }
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val v = a.value
                alpha = v
                val sc = 0.93f + 0.07f * v
                scaleX = sc
                scaleY = sc
            },
    ) { content() }
}

// ---------------------------------------------------------------------------------------------
// content layouts. All sizes derive from the pill height, and every horizontal inset keeps the
// icon clear of the rounded end cap (inset = vertical margin + 10% of height), so nothing looks
// "sunk" into the edge in Mini / Dual / Full.
// ---------------------------------------------------------------------------------------------

@Composable
private fun IslandContent(ev: IslandEvent?, shape: IslandShape, h: Float, style: IslandStyle) {
    if (ev == null) return
    when (shape) {
        IslandShape.MINI, IslandShape.DUAL -> CompactContent(ev, h, style)
        IslandShape.EXPANDED -> ExpandedContent(ev, h, style)
        IslandShape.FULL -> FullContent(ev, h, style)
        IslandShape.HIDDEN -> Unit
    }
}

private fun textStyle(style: IslandStyle, sizeSp: Float, weight: FontWeight, alpha: Float = 1f): TextStyle =
    TextStyle(
        color = Color.White.copy(alpha = alpha),
        fontSize = sizeSp.sp,
        fontWeight = weight,
        shadow = if (style == IslandStyle.GODLY_COLOR) Shadow(Color(0x66000000), Offset(0f, 1.5f), 5f) else null,
    )

@Composable
private fun Tile(ev: IslandEvent, sizeDp: Float, style: IslandStyle, iconFraction: Float) {
    val acc = IslandPalette.accent(ev.kind)
    val bg = if (style == IslandStyle.IPHONE_BLACK) {
        Modifier.background(Brush.linearGradient(listOf(acc.a, acc.b)), CircleShape)
    } else {
        Modifier.background(Color.White.copy(alpha = 0.24f), CircleShape)
    }
    Box(Modifier.size(sizeDp.dp).then(bg), contentAlignment = Alignment.Center) {
        IslandIcon(ev.kind, (sizeDp * iconFraction).dp)
    }
}

@Composable
private fun Bar(progress: Float, heightDp: Float, style: IslandStyle, kind: IslandKind, modifier: Modifier = Modifier) {
    val p = progress.coerceIn(0f, 1f)
    val acc = IslandPalette.accent(kind)
    val black = style == IslandStyle.IPHONE_BLACK
    val track = if (black) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.28f)
    val fill: Brush = if (black) Brush.horizontalGradient(listOf(acc.a, acc.b)) else SolidColor(Color.White)
    Box(
        modifier
            .fillMaxWidth()
            .height(heightDp.dp)
            .clip(CircleShape)
            .background(track),
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(p)
                .background(fill),
        )
    }
}

@Composable
private fun CompactContent(ev: IslandEvent, h: Float, style: IslandStyle) {
    val tile = h * 0.60f
    val inset = 0.5f * (h - tile) + 0.10f * h
    Row(
        Modifier
            .fillMaxSize()
            .padding(horizontal = inset.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy((h * 0.18f).dp),
    ) {
        Tile(ev, tile, style, 0.70f)
        Text(
            text = ev.value ?: ev.title,
            style = textStyle(style, h * 0.34f, FontWeight.SemiBold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun ExpandedContent(ev: IslandEvent, h: Float, style: IslandStyle) {
    val tile = h * 0.56f
    val inset = 0.5f * (h - tile) + 0.10f * h
    Row(
        Modifier
            .fillMaxSize()
            .padding(horizontal = inset.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy((h * 0.17f).dp),
    ) {
        Tile(ev, tile, style, 0.62f)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(
                text = ev.title,
                style = textStyle(style, h * 0.21f, FontWeight.Bold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = ev.subtitle,
                style = textStyle(style, h * 0.165f, FontWeight.Normal, 0.88f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            val p = ev.progress
            if (p != null) {
                Bar(p, h * 0.055f, style, ev.kind, Modifier.padding(top = (h * 0.06f).dp))
            }
        }
        val v = ev.value
        if (v != null) {
            Text(text = v, style = textStyle(style, h * 0.21f, FontWeight.Bold), maxLines = 1)
        }
    }
}

@Composable
private fun FullContent(ev: IslandEvent, h: Float, style: IslandStyle) {
    val tile = (h * 0.29f).coerceAtMost(56f)
    val pad = (h * 0.11f).coerceIn(14f, 22f)
    Column(
        Modifier
            .fillMaxSize()
            .padding(pad.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Tile(ev, tile, style, 0.62f)
            Column(Modifier.weight(1f)) {
                Text(
                    text = ev.title,
                    style = textStyle(style, 19f, FontWeight.ExtraBold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = ev.subtitle,
                    style = textStyle(style, 13f, FontWeight.Normal, 0.88f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            val v = ev.value
            if (v != null) {
                Text(text = v, style = textStyle(style, 19f, FontWeight.Bold), maxLines = 1)
            }
        }
        val p = ev.progress
        if (p != null) {
            Bar(p, 6f, style, ev.kind)
        }
        val tag = if (ev.simulated) ev.kind.label.uppercase() + "  •  SIMULATED" else ev.kind.label.uppercase()
        Text(text = tag, style = textStyle(style, 10.5f, FontWeight.Medium, 0.7f), maxLines = 1)
    }
}
