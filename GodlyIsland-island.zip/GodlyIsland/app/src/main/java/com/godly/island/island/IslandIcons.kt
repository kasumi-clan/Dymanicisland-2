package com.godly.island.island

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import com.godly.island.events.IslandKind

private class ParsedLayer(val path: Path, val src: IconLayer)

private val parsedCache = HashMap<List<IconLayer>, List<ParsedLayer>>()

private fun parsed(art: List<IconLayer>): List<ParsedLayer> = synchronized(parsedCache) {
    parsedCache.getOrPut(art) {
        art.map { ParsedLayer(PathParser().parsePathString(it.d).toPath(), it) }
    }
}

internal fun artFor(kind: IslandKind): List<IconLayer> = when (kind) {
    IslandKind.CALL_INCOMING -> IconArt.CALL_RING
    IslandKind.CALL_ONGOING -> IconArt.CALL_LIVE
    IslandKind.MUSIC -> IconArt.MUSIC
    IslandKind.BATTERY_LOW -> IconArt.BATTERY_LOW
    IslandKind.BATTERY_FULL -> IconArt.BATTERY
    IslandKind.CHARGING -> IconArt.CHARGING
    IslandKind.NOTIFICATION -> IconArt.BELL
    IslandKind.TIMER -> IconArt.TIMER
    IslandKind.NAVIGATION -> IconArt.NAV
    IslandKind.BLUETOOTH -> IconArt.BLUETOOTH
    IslandKind.DOWNLOAD -> IconArt.DOWNLOAD
    IslandKind.AI_PROCESSING -> IconArt.SPARKLE
}

/** Draws the hand-made icon for [kind] (vector paths, no emoji, no fonts). */
@Composable
fun IslandIcon(
    kind: IslandKind,
    size: Dp,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
) {
    val layers = remember(kind) { parsed(artFor(kind)) }
    Canvas(modifier.size(size)) {
        val k = this.size.minDimension / 24f
        scale(k, k, Offset.Zero) {
            for (l in layers) paintLayer(l, tint)
        }
    }
}

private fun DrawScope.paintLayer(l: ParsedLayer, tint: Color) {
    val c = tint.copy(alpha = (tint.alpha * l.src.alpha).coerceIn(0f, 1f))
    if (l.src.sc != 1f || l.src.tx != 0f || l.src.ty != 0f) {
        translate(l.src.tx, l.src.ty) {
            scale(l.src.sc, l.src.sc, Offset.Zero) { paintPath(l, c) }
        }
    } else {
        paintPath(l, c)
    }
}

private fun DrawScope.paintPath(l: ParsedLayer, c: Color) {
    if (l.src.fill) {
        drawPath(l.path, c)
    } else {
        drawPath(l.path, c, style = Stroke(width = l.src.width, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
