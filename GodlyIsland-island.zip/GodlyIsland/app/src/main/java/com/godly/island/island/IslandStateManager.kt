package com.godly.island.island

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Decides the Island's shape from the events:
 *  - nothing to show      -> idle MINI pill (or HIDDEN if the idle pill is switched off)
 *  - a NEW event          -> EXPANDED for ~3.5 s ("attention"), then back to MINI
 *  - two or more events   -> DUAL
 *  - tap / long press     -> user override (EXPANDED / FULL) that relaxes after 8 s
 *  - Settings preview     -> [previewShape] wins over everything
 */
object IslandStateManager {
    var shape by mutableStateOf(IslandShape.MINI)
        private set

    /** Set by the Settings screen to show a given size on the real Island; null = off. */
    var previewShape by mutableStateOf<IslandShape?>(null)

    private var userShape: IslandShape? = null
    private var attention = false
    private val handler = Handler(Looper.getMainLooper())

    private val endAttention = Runnable {
        attention = false
        resolve()
    }
    private val endUser = Runnable {
        userShape = null
        resolve()
    }

    fun onEventsChanged(newEvent: Boolean) {
        if (newEvent) {
            userShape = null
            attention = true
            handler.removeCallbacks(endAttention)
            handler.postDelayed(endAttention, 3500L)
        }
        resolve()
    }

    fun onSettingsChanged() = resolve()

    fun onTap() {
        if (IslandEventManager.events.isEmpty()) return
        attention = false
        handler.removeCallbacks(endAttention)
        val expanded = shape == IslandShape.EXPANDED || shape == IslandShape.FULL
        userShape = if (expanded) null else IslandShape.EXPANDED
        scheduleEndUser()
        resolve()
    }

    fun onLongPress() {
        if (IslandEventManager.events.isEmpty()) return
        attention = false
        handler.removeCallbacks(endAttention)
        userShape = IslandShape.FULL
        scheduleEndUser()
        resolve()
    }

    fun onSwipeUp() {
        IslandEventManager.dismissTop()
    }

    private fun scheduleEndUser() {
        handler.removeCallbacks(endUser)
        handler.postDelayed(endUser, 8000L)
    }

    private fun resolve() {
        val s = IslandRuntime.settings
        val count = IslandEventManager.events.size
        val p = previewShape
        val u = userShape
        shape = when {
            p != null -> p
            count == 0 -> if (s.showIdle) IslandShape.MINI else IslandShape.HIDDEN
            u != null -> u
            count >= 2 -> if (attention) IslandShape.EXPANDED else IslandShape.DUAL
            attention -> IslandShape.EXPANDED
            else -> IslandShape.MINI
        }
    }
}
