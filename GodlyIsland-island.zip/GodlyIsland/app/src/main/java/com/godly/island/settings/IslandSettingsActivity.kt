package com.godly.island.settings

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.godly.island.core.GodlyButton
import com.godly.island.core.GodlyCard
import com.godly.island.core.GodlyChip
import com.godly.island.core.GodlyColors
import com.godly.island.core.GodlyTheme
import com.godly.island.core.SectionTitle
import com.godly.island.island.IslandLauncher
import com.godly.island.island.IslandPreviewControl
import com.godly.island.island.IslandRuntime
import com.godly.island.island.IslandSettings
import com.godly.island.island.IslandShape
import com.godly.island.island.IslandStyle
import java.util.Locale
import kotlin.math.roundToInt

/** Settings for the real Island: on/off, style, width/height of every size, position, colour. */
class IslandSettingsActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        IslandRuntime.load(this)
        setContent { GodlyTheme { SettingsScreen(resumeTick) } }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    override fun onPause() {
        IslandPreviewControl.stop()
        super.onPause()
    }
}

@Composable
private fun SettingsScreen(tick: Int) {
    val context = LocalContext.current
    val s = IslandRuntime.settings
    val running = IslandRuntime.running
    val overlayOk = remember(tick) { IslandLauncher.hasOverlayPermission(context) }
    var previewSel by remember { mutableStateOf<IslandShape?>(null) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun change(save: Boolean, f: (IslandSettings) -> IslandSettings) = IslandRuntime.update(context, save, f)
    fun done() = IslandRuntime.persist(context)
    fun previewFor(shape: IslandShape) {
        if (running && previewSel != shape) {
            IslandPreviewControl.show(shape)
            previewSel = shape
        }
    }

    androidx.compose.foundation.layout.Box(Modifier.fillMaxSize().background(GodlyColors.Ink)) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Cài đặt Dynamic Island", color = GodlyColors.Paper, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "Mọi thay đổi áp dụng ngay lên Island thật ở đỉnh màn hình.",
                color = GodlyColors.Muted,
                fontSize = 12.sp,
            )

            GodlyCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SectionTitle("Bật Dynamic Island")
                        Text(
                            if (running) "Đang chạy" else "Đang tắt",
                            color = if (running) GodlyColors.Ok else GodlyColors.Muted,
                            fontSize = 12.sp,
                        )
                    }
                    Switch(
                        checked = running,
                        onCheckedChange = { on ->
                            if (on) {
                                if (Build.VERSION.SDK_INT >= 33 &&
                                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                                    PackageManager.PERMISSION_GRANTED
                                ) {
                                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                IslandLauncher.start(context)
                            } else {
                                IslandPreviewControl.stop()
                                previewSel = null
                                IslandLauncher.stop(context)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = GodlyColors.Ink,
                            checkedTrackColor = GodlyColors.Paper,
                        ),
                    )
                }
                if (!overlayOk) {
                    Text(
                        "Cần quyền \"Hiển thị trên các ứng dụng khác\" để vẽ Island. Bạn tự bật trong cài đặt hệ thống.",
                        color = GodlyColors.Warn,
                        fontSize = 12.sp,
                    )
                    GodlyButton("Cấp quyền hiển thị trên ứng dụng khác", { IslandLauncher.openOverlaySettings(context) }, Modifier.fillMaxWidth())
                }
            }

            GodlyCard {
                SectionTitle("Kiểu")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (st in IslandStyle.values()) {
                        GodlyChip(st.label, s.style == st, { change(true) { it.copy(style = st) } })
                    }
                }
                GodlyButton(
                    "Dùng cỡ + kiểu iPhone 14 Pro Max (đen)",
                    { change(true) { it.withIphonePreset() } },
                    Modifier.fillMaxWidth(),
                )
                SwitchRow("Luôn hiện đảo nhỏ quanh camera", s.showIdle) { v -> change(true) { it.copy(showIdle = v) } }
                SwitchRow("Kính shader GPU (tắt nếu thấy nóng máy)", s.useShader) { v -> change(true) { it.copy(useShader = v) } }
            }

            GodlyCard {
                SectionTitle("Xem trước trên Island thật")
                Text(
                    if (running) "Chọn một cỡ để Island thật hiện thử (sự kiện giả lập)." else "Bật Island ở trên để xem trước.",
                    color = GodlyColors.Muted,
                    fontSize = 12.sp,
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (sh in listOf(IslandShape.MINI, IslandShape.EXPANDED, IslandShape.FULL, IslandShape.DUAL)) {
                        GodlyChip(sh.label, previewSel == sh, { previewFor(sh) }, enabled = running)
                    }
                    GodlyChip(
                        "Tắt xem trước",
                        previewSel == null,
                        {
                            IslandPreviewControl.stop()
                            previewSel = null
                        },
                        enabled = running,
                    )
                }
            }

            GodlyCard {
                SectionTitle("Kích thước (dp)")
                Text("Mini — đảo nhỏ", color = GodlyColors.Muted, fontSize = 12.sp)
                SizeSlider("Chiều ngang", s.miniW, 80f, 240f, "dp", { v -> change(false) { it.copy(miniW = v) }; previewFor(IslandShape.MINI) }, { done() })
                SizeSlider("Chiều cao", s.miniH, 26f, 60f, "dp", { v -> change(false) { it.copy(miniH = v) }; previewFor(IslandShape.MINI) }, { done() })
                Text("Expanded — khi có sự kiện", color = GodlyColors.Muted, fontSize = 12.sp)
                SizeSlider("Chiều ngang", s.expW, 180f, 440f, "dp", { v -> change(false) { it.copy(expW = v) }; previewFor(IslandShape.EXPANDED) }, { done() })
                SizeSlider("Chiều cao", s.expH, 48f, 130f, "dp", { v -> change(false) { it.copy(expH = v) }; previewFor(IslandShape.EXPANDED) }, { done() })
                Text("Full — nhấn giữ để mở", color = GodlyColors.Muted, fontSize = 12.sp)
                SizeSlider("Chiều ngang", s.fullW, 220f, 440f, "dp", { v -> change(false) { it.copy(fullW = v) }; previewFor(IslandShape.FULL) }, { done() })
                SizeSlider("Chiều cao", s.fullH, 100f, 280f, "dp", { v -> change(false) { it.copy(fullH = v) }; previewFor(IslandShape.FULL) }, { done() })
                Text("Dual tự lấy chiều ngang Mini × 1,18 cho mỗi viên.", color = GodlyColors.Muted, fontSize = 11.sp)
            }

            GodlyCard {
                SectionTitle("Vị trí (căn đúng camera)")
                Text(
                    "Android tự căn theo lỗ camera nếu máy báo vị trí. Nếu lệch, chỉnh tại đây.",
                    color = GodlyColors.Muted,
                    fontSize = 12.sp,
                )
                SizeSlider("Ngang (trái ↔ phải)", s.offsetX, -80f, 80f, "dp", { v -> change(false) { it.copy(offsetX = v) }; previewFor(IslandShape.MINI) }, { done() })
                SizeSlider("Dọc (lên ↔ xuống)", s.offsetY, -24f, 40f, "dp", { v -> change(false) { it.copy(offsetY = v) }; previewFor(IslandShape.MINI) }, { done() })
            }

            GodlyCard {
                SectionTitle("Màu & kính")
                PctSlider("Độ sáng màu", s.brightness, { v -> change(false) { it.copy(brightness = v) } }, { done() })
                PctSlider("Độ \"hút vào\" ở mép kính", s.lens, { v -> change(false) { it.copy(lens = v) } }, { done() })
                Text("Chỉ áp dụng cho kiểu Godly Color. Kiểu iPhone luôn đen thuần.", color = GodlyColors.Muted, fontSize = 11.sp)
            }

            GodlyButton(
                "Khôi phục mặc định",
                { change(true) { IslandSettings(enabled = it.enabled) } },
                Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = GodlyColors.Paper, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = GodlyColors.Ink, checkedTrackColor = GodlyColors.Paper),
        )
    }
}

@Composable
private fun SizeSlider(
    label: String,
    value: Float,
    min: Float,
    max: Float,
    unit: String,
    onChange: (Float) -> Unit,
    onDone: () -> Unit,
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = GodlyColors.Paper, fontSize = 12.sp)
            Text(value.roundToInt().toString() + " " + unit, color = GodlyColors.Muted, fontSize = 12.sp)
        }
        Slider(
            value = value.coerceIn(min, max),
            onValueChange = onChange,
            onValueChangeFinished = onDone,
            valueRange = min..max,
            colors = sliderColors(),
        )
    }
}

@Composable
private fun PctSlider(label: String, value: Float, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = GodlyColors.Paper, fontSize = 12.sp)
            Text(String.format(Locale.US, "%.0f%%", value * 100f), color = GodlyColors.Muted, fontSize = 12.sp)
        }
        Slider(
            value = value.coerceIn(0f, 1f),
            onValueChange = onChange,
            onValueChangeFinished = onDone,
            valueRange = 0f..1f,
            colors = sliderColors(),
        )
    }
}

@Composable
private fun sliderColors() = SliderDefaults.colors(
    thumbColor = GodlyColors.Paper,
    activeTrackColor = GodlyColors.Paper,
    inactiveTrackColor = Color.White.copy(alpha = 0.2f),
)
